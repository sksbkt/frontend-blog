"use client";

import { useLocale } from "next-intl";
import { usePathname, useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";

export function LanguageSwitcher() {
  const locale = useLocale();
  const router = useRouter();
  const pathname = usePathname();

  function switchLanguage() {
    const nextLocale = locale === "fa" ? "en" : "fa";

    router.replace(pathname.replace(`/${locale}`, `/${nextLocale}`));
  }

  return (
    <Button
      variant="outline"
      size="icon"
      onClick={switchLanguage}
    >
      <span className="translate-y-0.5 text-xs font-medium leading-none">
        {locale === "fa" ? "EN" : "FA"}
      </span>
    </Button>
  );
}
